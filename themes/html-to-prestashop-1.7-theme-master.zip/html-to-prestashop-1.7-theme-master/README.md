# html-to-prestashop-1.7-theme
Convert HTML template to a theme

This is the source used during the playlist shared on YouTube:
https://www.youtube.com/playlist?list=PLjXgd_2L4Wh9qdcDrWrNXvirrhfyx8_I2
